# Contributor Code of Conduct

Bu projeye katkıda bulunanlar olarak, açık ve misafirperver bir topluluğu
teşvik etmek adına, sorunları bildirerek, PR göndererek ve diğer faaliyetller
yoluyla katkıda bulunan herkese saygı göstermeyi taahhüt ediyoruz.

Bu projeye katkı sağlamayı deneyim düzeyi, cinsiyet, cinsel kimlik ve ifade,
cinsel yönelim, engellilik, kişisel görünüm, vücut ölçüsü, ırk, etnik köken,
yaş, din veya milliyet gözetmeksizin herkes için yargısız, açık bir durum
haline getirmeye adandık.

Katılımcıların kabul edilemeyecek davranışları şunlardır:

-   Cinselleştirilmiş dil veya görüntü kullanımı
-   Kişisel saldırılar
-   Trolleme veya hakaret/aşağılayıcı yorumlar
-   Kamusal veya özel taciz
-   Fiziksel veya özel adresler gibi başkalarının özel bilgilerini
    açık izin olmadan yayınlamak
-   Diğer etik olmayan veya profesyonel olmayan davranışlar
    Proje yürütücüleri, bu Davranış Kuralları ile uyumlu olmayan yorumları,
    taahhütleri, kodlamayı, wiki düzenlemelerini, sorunları ve diğer katkıları
    kaldırma, düzenleme veya reddetme, veya herhangi bir katkıda bulunanları
    geçici veya kalıcı olarak yasaklama hak sorumluluğuna sahiptir. Bu durumu
    uygunsuz, tehditkar, saldırgan veya zararlı olarak görürler.

Proje yürütücüleri, bu Davranış Kurallarını benimseyerek, bu ilkeleri
bu projeyi yönetmenin her yönüne adil ve tutarlı bir şekilde uygulamayı
taahhüt ederler. Davranış Kurallarına uymayan veya uygulamayan proje sahipleri,
proje ekibinden kalıcı olarak çıkarılabilir.

Bu davranış kuralları, hem proje alanlarında hem de bir kişi projeyi veya
topluluğunu temsil ettiğinde kamusal alanlarda geçerlidir.

Taciz edici, taciz edici veya başka türlü kabul edilemez davranış örnekleri,
victorfelder at gmail.com adresindeki bir proje yürütücüsüyle iletişime geçilerek
bildirilebilir. Tüm şikayetler incelenecek ve soruşturulacakve gerekli ve
koşullara uygun görülen bir yanıtla sonuçlanacaktır. Bakım görevlileri,
bir olayı bildiren kişiyle ilgili olarak gizliliği korumakla yükümlüdür.

Bu Davranış Kuralları şuradan uyarlanmıştır: [Contributor Covenant][homepage],
versiyon 1.3.0, bu adreste bulunabilir: https://contributor-covenant.org/version/1/3/0/

[Çeviriler](README.md#translations)

[homepage]: https://contributor-covenant.org
