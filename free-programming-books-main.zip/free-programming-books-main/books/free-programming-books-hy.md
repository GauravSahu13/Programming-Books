### Index

* [Python](#python)


### Python

* [Python Ուղեցույց](https://armath.am/uploads/E-learning/Robotics/RaspberryPi/python.pdf) - Վարդուհի Անդրեասյան (PDF)
