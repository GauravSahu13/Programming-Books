### Index

* [Programming News](#programming-news)
* [Technology](#technology)


### Programming News

* [پادکست کافه برنامه نویس](https://anchor.fm/codemy) - CafeCodemy (podcast)


### Technology

* [پارس کلیک](https://anchor.fm/parsclick/) - Amir Azimi (podcast)
* [رادیو گیک](https://soundcloud.com/jadijadi) (podcast)
* [رادیو گیک](https://anchor.fm/radiojadi) - Jadi (podcast)
* [رادیو گیک](https://www.youtube.com/playlist?list=PL-tKrPVkKKE1peHomci9EH7BmafxdXKGn) (videocast)
* [CodeNaline \| کدنالین](https://castbox.fm/channel/id5066732) - Torham (podcast)
* [Radio Developer - رادیو دولوپر](https://castbox.fm/channel/id4407294) (podcast)
* [Radio Mi \| رادیو میــ](https://www.youtube.com/playlist?list=PLRmRAhVbjeHqrc6Gf5DKu2eRJGkfo9A-Z) - Milad Nouri (videocast)
