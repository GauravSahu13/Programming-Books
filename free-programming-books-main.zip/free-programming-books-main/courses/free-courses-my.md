### Index

* [Database](#database)
* [Flutter](#flutter)
* [Python](#python)


### Database

* [Database Basic with MySQL](https://www.youtube.com/playlist?list=PLUbA5XRGtepKSdvEZI4FCi9_-UTQgnFxS) - Htain Lin Shwe


### Flutter

* [Flutter](https://www.youtube.com/playlist?list=PLUbA5XRGtepJZdgd6XMHF9-nPGQs57eys) - Htain Lin Shwe


### Python

* [Programming Basic](https://www.youtube.com/playlist?list=PLUbA5XRGtepL4W4hXBBXfqC1i3PaBxMtN) - Htain Lin Shwe
